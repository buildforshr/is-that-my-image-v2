from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from ncid.core.models import CandidateHashes, Fingerprint, Match, ScanRun, Tier

_SCHEMA = """
CREATE TABLE IF NOT EXISTS fingerprints (
    id INTEGER PRIMARY KEY,
    label TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    phash TEXT NOT NULL,
    dhash TEXT NOT NULL,
    ahash TEXT NOT NULL,
    whash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    source_path TEXT
);
CREATE TABLE IF NOT EXISTS scan_runs (
    id INTEGER PRIMARY KEY,
    source_spec TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL,
    pages_seen INTEGER NOT NULL DEFAULT 0,
    images_seen INTEGER NOT NULL DEFAULT 0,
    errors INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS matches (
    id INTEGER PRIMARY KEY,
    scan_run_id INTEGER NOT NULL REFERENCES scan_runs(id),
    fingerprint_id INTEGER REFERENCES fingerprints(id),
    tier TEXT NOT NULL,
    score INTEGER,
    image_url TEXT NOT NULL,
    page_url TEXT NOT NULL,
    page_title TEXT,
    matched_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS seen_pages (
    scan_run_id INTEGER NOT NULL REFERENCES scan_runs(id),
    url TEXT NOT NULL,
    PRIMARY KEY (scan_run_id, url)
);
"""


def _hex(v: int) -> str:
    return f"{v:016x}"


class Store:
    def __init__(self, db_path: Path) -> None:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "Store":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    # -- fingerprints ------------------------------------------------------
    def add_fingerprint(
        self, label: str, hashes: CandidateHashes, source_path: str | None
    ) -> Fingerprint:
        now = datetime.now(timezone.utc)
        cur = self._conn.execute(
            "INSERT INTO fingerprints (label, sha256, phash, dhash, ahash, whash,"
            " created_at, source_path) VALUES (?,?,?,?,?,?,?,?)",
            (label, hashes.sha256, _hex(hashes.phash), _hex(hashes.dhash),
             _hex(hashes.ahash), _hex(hashes.whash), now.isoformat(), source_path),
        )
        self._conn.commit()
        return Fingerprint(cur.lastrowid, label, hashes, now, source_path)

    def list_fingerprints(self) -> list[Fingerprint]:
        rows = self._conn.execute(
            "SELECT id, label, sha256, phash, dhash, ahash, whash, created_at,"
            " source_path FROM fingerprints ORDER BY id"
        ).fetchall()
        return [
            Fingerprint(
                r[0], r[1],
                CandidateHashes(r[2], int(r[3], 16), int(r[4], 16),
                                int(r[5], 16), int(r[6], 16)),
                datetime.fromisoformat(r[7]), r[8],
            )
            for r in rows
        ]

    def delete_fingerprint(self, fp_id: int) -> bool:
        cur = self._conn.execute("DELETE FROM fingerprints WHERE id = ?", (fp_id,))
        self._conn.commit()
        return cur.rowcount > 0

    def delete_all(self) -> None:
        for t in ("matches", "seen_pages", "scan_runs", "fingerprints"):
            self._conn.execute(f"DELETE FROM {t}")
        self._conn.commit()

    # -- scan runs ---------------------------------------------------------
    def create_scan_run(self, source_spec: str) -> ScanRun:
        now = datetime.now(timezone.utc)
        cur = self._conn.execute(
            "INSERT INTO scan_runs (source_spec, started_at, status) VALUES (?,?,?)",
            (source_spec, now.isoformat(), "running"),
        )
        self._conn.commit()
        return ScanRun(cur.lastrowid, source_spec, now)

    def update_scan_run(self, run: ScanRun) -> None:
        self._conn.execute(
            "UPDATE scan_runs SET finished_at=?, status=?, pages_seen=?,"
            " images_seen=?, errors=? WHERE id=?",
            (run.finished_at.isoformat() if run.finished_at else None, run.status,
             run.pages_seen, run.images_seen, run.errors, run.id),
        )
        self._conn.commit()

    def _row_to_run(self, r) -> ScanRun:
        return ScanRun(
            r[0], r[1], datetime.fromisoformat(r[2]),
            datetime.fromisoformat(r[3]) if r[3] else None, r[4], r[5], r[6], r[7],
        )

    def get_scan_run(self, run_id: int) -> ScanRun | None:
        r = self._conn.execute(
            "SELECT id, source_spec, started_at, finished_at, status, pages_seen,"
            " images_seen, errors FROM scan_runs WHERE id=?", (run_id,)
        ).fetchone()
        return self._row_to_run(r) if r else None

    def latest_scan_run(self) -> ScanRun | None:
        r = self._conn.execute(
            "SELECT id, source_spec, started_at, finished_at, status, pages_seen,"
            " images_seen, errors FROM scan_runs ORDER BY id DESC LIMIT 1"
        ).fetchone()
        return self._row_to_run(r) if r else None

    # -- matches -----------------------------------------------------------
    def add_match(self, run_id: int, m: Match) -> None:
        self._conn.execute(
            "INSERT INTO matches (scan_run_id, fingerprint_id, tier, score,"
            " image_url, page_url, page_title, matched_at) VALUES (?,?,?,?,?,?,?,?)",
            (run_id, m.fingerprint_id, m.tier.value, m.score, m.image_url,
             m.page_url, m.page_title, m.matched_at.isoformat()),
        )
        self._conn.commit()

    def matches_for_run(self, run_id: int) -> list[Match]:
        rows = self._conn.execute(
            "SELECT fingerprint_id, tier, score, image_url, page_url, page_title,"
            " matched_at FROM matches WHERE scan_run_id=? ORDER BY id", (run_id,)
        ).fetchall()
        return [
            Match(r[0], Tier(r[1]), r[2], r[3], r[4], r[5],
                  datetime.fromisoformat(r[6]))
            for r in rows
        ]

    # -- resume ------------------------------------------------------------
    def mark_page_seen(self, run_id: int, url: str) -> None:
        self._conn.execute(
            "INSERT OR IGNORE INTO seen_pages (scan_run_id, url) VALUES (?,?)",
            (run_id, url),
        )
        self._conn.commit()

    def seen_page_urls(self, run_id: int) -> set[str]:
        return {r[0] for r in self._conn.execute(
            "SELECT url FROM seen_pages WHERE scan_run_id=?", (run_id,))}
