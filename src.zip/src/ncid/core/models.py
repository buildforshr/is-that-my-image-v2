from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum


class Tier(StrEnum):
    EXACT = "exact"
    PROBABLE = "probable"
    POSSIBLE = "possible"
    UNVERIFIED_LEAD = "unverified-lead"


@dataclass(frozen=True)
class CandidateHashes:
    sha256: str
    phash: int
    dhash: int
    ahash: int
    whash: int


@dataclass(frozen=True)
class Fingerprint:
    id: int | None
    label: str
    hashes: CandidateHashes
    created_at: datetime
    source_path: str | None


@dataclass(frozen=True)
class Candidate:
    image_url: str
    page_url: str
    page_title: str | None = None


@dataclass(frozen=True)
class Match:
    fingerprint_id: int | None
    tier: Tier
    score: int | None
    image_url: str
    page_url: str
    page_title: str | None
    matched_at: datetime


@dataclass
class ScanRun:
    id: int | None
    source_spec: str
    started_at: datetime
    finished_at: datetime | None = None
    status: str = "running"
    pages_seen: int = 0
    images_seen: int = 0
    errors: int = 0
