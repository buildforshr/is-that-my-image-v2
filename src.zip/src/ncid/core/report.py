from __future__ import annotations

import json

from ncid.core.models import Match, ScanRun, Tier

_NEEDS_CONFIRMATION = {Tier.POSSIBLE, Tier.UNVERIFIED_LEAD}
_TIER_ORDER = [Tier.EXACT, Tier.PROBABLE, Tier.POSSIBLE, Tier.UNVERIFIED_LEAD]
_TIER_HEADINGS = {
    Tier.EXACT: "Exact matches",
    Tier.PROBABLE: "Probable matches",
    Tier.POSSIBLE: "Possible matches (needs human confirmation)",
    Tier.UNVERIFIED_LEAD: "Unverified engine leads (needs human confirmation)",
}


def build_report(run: ScanRun, matches: list[Match]) -> dict:
    counts = {t.value: 0 for t in _TIER_ORDER}
    entries = []
    for m in matches:
        counts[m.tier.value] += 1
        entries.append({
            "tier": m.tier.value,
            "score": m.score,
            "image_url": m.image_url,
            "page_url": m.page_url,
            "page_title": m.page_title,
            "matched_at": m.matched_at.isoformat(),
            "needs_confirmation": m.tier in _NEEDS_CONFIRMATION,
        })
    counts["errors"] = run.errors
    return {
        "scan": {
            "id": run.id, "source": run.source_spec,
            "started_at": run.started_at.isoformat(),
            "finished_at": run.finished_at.isoformat() if run.finished_at else None,
            "status": run.status, "pages_seen": run.pages_seen,
            "images_seen": run.images_seen, "errors": run.errors,
        },
        "matches": entries,
        "counts": counts,
    }


def to_json(report: dict) -> str:
    return json.dumps(report, indent=2, sort_keys=True)


def to_markdown(report: dict) -> str:
    scan = report["scan"]
    lines = [
        f"# ncid scan report — run {scan['id']}",
        "",
        f"Source: `{scan['source']}`  |  Status: {scan['status']}",
        f"Pages: {scan['pages_seen']}  |  Images checked: {scan['images_seen']}",
        "",
    ]
    for tier in _TIER_ORDER:
        section = [m for m in report["matches"] if m["tier"] == tier.value]
        if not section:
            continue
        lines.append(f"## {_TIER_HEADINGS[tier]}")
        for m in section:
            score = f" (distance {m['score']})" if m["score"] is not None else ""
            title = f" — {m['page_title']}" if m["page_title"] else ""
            lines.append(f"- {m['page_url']}{title}{score}")
            if m["image_url"]:
                lines.append(f"  - image: {m['image_url']}")
        lines.append("")
    lines.append(f"Skipped/errored candidates: {scan['errors']}")
    return "\n".join(lines)
