from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, replace
from pathlib import Path

import platformdirs

_TOML_NUMERIC_KEYS = ("max_image_bytes", "max_pages", "max_depth", "per_host_delay")


@dataclass(frozen=True)
class Config:
    data_dir: Path
    max_image_bytes: int = 15_000_000
    max_pages: int = 200
    max_depth: int = 3
    per_host_delay: float = 1.0
    user_agent: str = "ncid/0.1"
    google_api_key: str | None = None
    reddit_client_id: str | None = None
    reddit_client_secret: str | None = None


def load_config() -> Config:
    data_dir = Path(os.environ.get("NCID_DATA_DIR")
                    or platformdirs.user_data_dir("ncid"))
    cfg = Config(
        data_dir=data_dir,
        google_api_key=os.environ.get("NCID_GOOGLE_API_KEY"),
        reddit_client_id=os.environ.get("NCID_REDDIT_CLIENT_ID"),
        reddit_client_secret=os.environ.get("NCID_REDDIT_CLIENT_SECRET"),
    )
    config_dir = Path(os.environ.get("NCID_CONFIG_DIR")
                      or platformdirs.user_config_dir("ncid"))
    toml_path = config_dir / "config.toml"
    if toml_path.exists():
        loaded = tomllib.loads(toml_path.read_text())
        overrides = {k: loaded[k] for k in _TOML_NUMERIC_KEYS if k in loaded}
        cfg = replace(cfg, **overrides)  # keys deliberately not overridable (I5)
    return cfg


def db_path(cfg: Config) -> Path:
    return cfg.data_dir / "ncid.db"
