from __future__ import annotations

import asyncio
from dataclasses import replace
from datetime import datetime, timezone

import httpx

from ncid.core.config import Config
from ncid.core.fingerprint import ImageDecodeError, compute_hashes
from ncid.core.matcher import best_match
from ncid.core.models import Match, ScanRun, Tier
from ncid.core.sources.base import DownloadRejected, SourceAdapter, download_image
from ncid.core.sources.crawler import CrawlerAdapter
from ncid.core.sources.engines.google_vision import Lead
from ncid.core.store import Store

_PROGRESS_EVERY = 25


async def run_scan(store: Store, adapter: SourceAdapter, run: ScanRun) -> ScanRun:
    fingerprints = store.list_fingerprints()
    try:
        async for candidate, data in adapter.iter_candidates():
            run.images_seen += 1
            try:
                hashes = compute_hashes(data)
            except ImageDecodeError:
                run.errors += 1
                continue
            finally:
                del data  # candidate bytes must not outlive this iteration (I3)
            if found := best_match(fingerprints, hashes):
                fp, tier, score = found
                store.add_match(run.id, Match(
                    fp.id, tier, score, candidate.image_url, candidate.page_url,
                    candidate.page_title, datetime.now(timezone.utc)))
            if run.images_seen % _PROGRESS_EVERY == 0:
                store.update_scan_run(run)
    except asyncio.CancelledError:
        run.status = "interrupted"
        store.update_scan_run(run)
        raise
    run.status = "finished"
    run.finished_at = datetime.now(timezone.utc)
    store.update_scan_run(run)
    return run


async def verify_leads(
    store: Store,
    client: httpx.AsyncClient,
    cfg: Config,
    run: ScanRun,
    leads: list[Lead],
) -> ScanRun:
    """Engine leads are hints; only a local hash match confirms them (spec §6.3)."""
    fingerprints = store.list_fingerprints()
    for lead in leads:
        confirmed = False
        if lead.image_url:
            try:
                data = await download_image(client, lead.image_url, cfg.max_image_bytes)
                try:
                    hashes = compute_hashes(data)
                finally:
                    del data  # candidate bytes must not outlive this iteration (I3)
                if found := best_match(fingerprints, hashes):
                    fp, tier, score = found
                    store.add_match(run.id, Match(
                        fp.id, tier, score, lead.image_url,
                        lead.page_url or lead.image_url, None,
                        datetime.now(timezone.utc)))
                    confirmed = True
            except (DownloadRejected, ImageDecodeError):
                run.errors += 1
        elif lead.page_url:
            # max_depth=0: verify the lead page (and its images) only. Links
            # found on it are never queued, so this crawl cannot wander the
            # domain and "confirm" the lead via some unrelated page it
            # happens to link to (spec §6.3: engine leads are hints; only a
            # match ON the lead's own page counts as local confirmation).
            verify_cfg = replace(cfg, max_pages=1, max_depth=0)
            adapter = CrawlerAdapter(client, verify_cfg, [lead.page_url],
                                     same_domain_only=True)
            before = store.matches_for_run(run.id)
            await run_scan(store, adapter, run)
            after = store.matches_for_run(run.id)
            new_matches = after[len(before):]
            confirmed = any(m.page_url == lead.page_url for m in new_matches)
        if not confirmed:
            store.add_match(run.id, Match(
                None, Tier.UNVERIFIED_LEAD, None,
                lead.image_url or "", lead.page_url or lead.image_url or "",
                None, datetime.now(timezone.utc)))
    store.update_scan_run(run)
    return run
