from __future__ import annotations

import asyncio
from collections import deque
from collections.abc import AsyncIterator, Callable
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import httpx
from selectolax.parser import HTMLParser

from ncid.core.config import Config
from ncid.core.models import Candidate
from ncid.core.sources.base import DownloadRejected, download_image

_IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".gif", ".webp")
_RETRY_DELAY = 5.0  # spec §8: sleep on 429, then retry once


class CrawlerAdapter:
    def __init__(
        self,
        client: httpx.AsyncClient,
        cfg: Config,
        start_urls: list[str],
        same_domain_only: bool,
        skip_pages: set[str] | None = None,
        on_page: Callable[[str], None] | None = None,
        on_error: Callable[[str], None] | None = None,
    ) -> None:
        self._client = client
        self._cfg = cfg
        self._start_urls = start_urls
        self._same_domain_only = same_domain_only
        self._skip_pages = skip_pages or set()
        self._on_page = on_page or (lambda url: None)
        self._on_error = on_error or (lambda detail: None)
        self._robots: dict[str, RobotFileParser] = {}

    async def _allowed(self, url: str) -> bool:
        host = urlparse(url).netloc
        if host not in self._robots:
            rp = RobotFileParser()
            robots_url = urljoin(url, "/robots.txt")
            try:
                resp = await self._client.get(robots_url)
                rp.parse(resp.text.splitlines() if resp.status_code == 200 else [])
            except httpx.HTTPError:
                rp.parse([])  # unreachable robots -> allow (matches browsers)
            self._robots[host] = rp
        return self._robots[host].can_fetch(self._cfg.user_agent, url)

    def _extract(self, base_url: str, html: str) -> tuple[str | None, set[str], set[str]]:
        tree = HTMLParser(html)
        title_node = tree.css_first("title")
        title = title_node.text(strip=True) if title_node else None
        images: set[str] = set()
        links: set[str] = set()
        for node in tree.css("img"):
            if src := node.attributes.get("src"):
                images.add(urljoin(base_url, src))
            if srcset := node.attributes.get("srcset"):
                for entry in srcset.split(","):
                    if url_part := entry.strip().split(" ")[0]:
                        images.add(urljoin(base_url, url_part))
        for node in tree.css('meta[property="og:image"]'):
            if content := node.attributes.get("content"):
                images.add(urljoin(base_url, content))
        for node in tree.css("a"):
            if href := node.attributes.get("href"):
                absolute = urljoin(base_url, href)
                if absolute.lower().endswith(_IMAGE_EXTS):
                    images.add(absolute)
                else:
                    links.add(absolute)
        return title, images, links

    async def iter_candidates(self) -> AsyncIterator[tuple[Candidate, bytes]]:
        queue: deque[tuple[str, int]] = deque((u, 0) for u in self._start_urls)
        visited: set[str] = set(self._skip_pages)
        seen_images: set[str] = set()
        retried_429: set[str] = set()
        pages_fetched = 0
        start_hosts = {urlparse(u).netloc for u in self._start_urls}

        while queue and pages_fetched < self._cfg.max_pages:
            page_url, depth = queue.popleft()
            if page_url in visited:
                continue
            visited.add(page_url)
            if self._same_domain_only and urlparse(page_url).netloc not in start_hosts:
                self._on_error(f"same-domain skip: {page_url}")
                continue
            if not await self._allowed(page_url):
                self._on_error(f"robots disallowed: {page_url}")
                continue
            await asyncio.sleep(self._cfg.per_host_delay)
            try:
                resp = await self._client.get(page_url)
            except httpx.HTTPError as e:
                self._on_error(f"page fetch failed: {page_url}: {e}")
                continue
            if resp.status_code == 429:  # spec §8: sleep, retry once, then give up
                if page_url in retried_429:
                    self._on_error(f"gave up after 429 retry: {page_url}")
                    continue
                retried_429.add(page_url)
                await asyncio.sleep(_RETRY_DELAY)
                visited.discard(page_url)
                queue.append((page_url, depth))
                continue
            pages_fetched += 1
            self._on_page(page_url)
            if not resp.headers.get("content-type", "").startswith("text/html"):
                continue
            title, images, links = self._extract(page_url, resp.text)
            for image_url in images:
                if image_url in seen_images:
                    continue
                seen_images.add(image_url)
                if not await self._allowed(image_url):
                    self._on_error(f"robots disallowed: {image_url}")
                    continue
                try:
                    data = await download_image(
                        self._client, image_url, self._cfg.max_image_bytes)
                except DownloadRejected as e:
                    self._on_error(f"candidate skipped: {e}")
                    continue
                yield Candidate(image_url, page_url, title), data
            if depth < self._cfg.max_depth:
                for link in links:
                    if link not in visited:
                        queue.append((link, depth + 1))
