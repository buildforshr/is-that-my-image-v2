from __future__ import annotations

import asyncio
import html
from collections.abc import AsyncIterator, Callable

import httpx

from ncid.core.config import Config
from ncid.core.models import Candidate
from ncid.core.sources.base import DownloadRejected, download_image

_IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".gif", ".webp")
_TOKEN_URL = "https://www.reddit.com/api/v1/access_token"
_API = "https://oauth.reddit.com"
_RETRY_DELAY = 5.0  # spec §8: sleep on 429, then retry once


class RedditAuthError(Exception):
    pass


class RedditAdapter:
    def __init__(
        self,
        client: httpx.AsyncClient,
        cfg: Config,
        target: str,
        max_posts: int = 200,
        on_error: Callable[[str], None] | None = None,
    ) -> None:
        self._client = client
        self._cfg = cfg
        self._target = target
        self._max_posts = max_posts
        self._on_error = on_error or (lambda detail: None)

    async def _token(self) -> str:
        if not (self._cfg.reddit_client_id and self._cfg.reddit_client_secret):
            raise RedditAuthError(
                "Reddit credentials missing: set NCID_REDDIT_CLIENT_ID and"
                " NCID_REDDIT_CLIENT_SECRET (script-type app at"
                " https://www.reddit.com/prefs/apps)")
        resp = await self._client.post(
            _TOKEN_URL,
            data={"grant_type": "client_credentials"},
            auth=(self._cfg.reddit_client_id, self._cfg.reddit_client_secret),
            headers={"User-Agent": self._cfg.user_agent},
        )
        if resp.status_code != 200:
            raise RedditAuthError(
                f"Reddit token request failed ({resp.status_code}); verify"
                " NCID_REDDIT_CLIENT_ID and NCID_REDDIT_CLIENT_SECRET are correct")
        return resp.json()["access_token"]

    def _listing_url(self) -> str:
        kind, _, name = self._target.partition("/")
        if kind == "r":
            return f"{_API}/r/{name}/new"
        return f"{_API}/user/{name}/submitted"

    @staticmethod
    def _image_urls(post: dict) -> set[str]:
        urls: set[str] = set()
        direct = post.get("url_overridden_by_dest") or ""
        if direct.lower().endswith(_IMAGE_EXTS):
            urls.add(direct)
        for img in (post.get("preview") or {}).get("images", []):
            if source_url := (img.get("source") or {}).get("url"):
                urls.add(html.unescape(source_url))
        for meta in (post.get("media_metadata") or {}).values():
            if gallery_url := (meta.get("s") or {}).get("u"):
                urls.add(html.unescape(gallery_url))
        return urls

    async def iter_candidates(self) -> AsyncIterator[tuple[Candidate, bytes]]:
        token = await self._token()
        headers = {"Authorization": f"Bearer {token}",
                   "User-Agent": self._cfg.user_agent}
        after: str | None = None
        seen_posts = 0
        retried_429 = False
        while seen_posts < self._max_posts:
            params = {"limit": "100"} | ({"after": after} if after else {})
            resp = await self._client.get(
                self._listing_url(), params=params, headers=headers)
            if resp.status_code == 429:  # spec §8: sleep, retry once, then give up
                if retried_429:
                    self._on_error(
                        f"gave up after 429 retry: {self._listing_url()}")
                    return
                retried_429 = True
                await asyncio.sleep(_RETRY_DELAY)
                continue
            retried_429 = False
            if resp.status_code != 200:
                self._on_error(f"reddit listing failed: {resp.status_code}")
                return
            data = resp.json()["data"]
            for child in data["children"]:
                post = child["data"]
                seen_posts += 1
                page_url = "https://www.reddit.com" + post.get("permalink", "/")
                for image_url in self._image_urls(post):
                    try:
                        img = await download_image(
                            self._client, image_url, self._cfg.max_image_bytes)
                    except DownloadRejected as e:
                        self._on_error(f"candidate skipped: {e}")
                        continue
                    yield Candidate(image_url, page_url, post.get("title")), img
                if seen_posts >= self._max_posts:
                    break
            after = data.get("after")
            if not after:
                return
