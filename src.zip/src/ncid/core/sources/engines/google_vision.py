from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass

import httpx

from ncid.core.sources.engines.base import ConsentToken, validate_token

_ENDPOINT = "https://vision.googleapis.com/v1/images:annotate"


class EngineError(Exception):
    pass


@dataclass(frozen=True)
class Lead:
    page_url: str | None
    image_url: str | None


class GoogleVisionEngine:
    name = "google"

    def __init__(self, client: httpx.AsyncClient, api_key: str) -> None:
        self._client = client
        self._api_key = api_key

    async def search(self, image_bytes: bytes, token: ConsentToken) -> list[Lead]:
        validate_token(token, self.name, hashlib.sha256(image_bytes).hexdigest())
        payload = {"requests": [{
            "image": {"content": base64.b64encode(image_bytes).decode()},
            "features": [{"type": "WEB_DETECTION", "maxResults": 50}],
        }]}
        resp = await self._client.post(
            _ENDPOINT, params={"key": self._api_key}, json=payload)
        if resp.status_code != 200:
            raise EngineError(
                f"Google Vision returned {resp.status_code}: {resp.text[:300]}."
                " Check NCID_GOOGLE_API_KEY, Vision API enablement, and quota.")
        body = resp.json()["responses"][0]
        if error := body.get("error"):
            # Vision API reports per-image failures with HTTP 200 and the
            # real error nested in responses[0].error (spec §8: no silent
            # fallbacks -- a 200 with an embedded error must not read as
            # "zero leads found").
            raise EngineError(
                f"Google Vision returned an error: {error.get('message', error)}."
                " Check NCID_GOOGLE_API_KEY, Vision API enablement, and quota.")
        detection = body.get("webDetection", {})
        leads: list[Lead] = []
        for page in detection.get("pagesWithMatchingImages", []):
            if url := page.get("url"):
                leads.append(Lead(page_url=url, image_url=None))
        for key in ("fullMatchingImages", "partialMatchingImages"):
            for image in detection.get(key, []):
                if url := image.get("url"):
                    leads.append(Lead(page_url=None, image_url=url))
        return leads
