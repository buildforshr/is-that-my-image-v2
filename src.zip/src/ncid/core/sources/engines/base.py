from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

CONSENT_WORD = "SEND"

_ENGINE_COMPANY = {"google": "Google"}


class ConsentError(Exception):
    pass


@dataclass(frozen=True)
class ConsentToken:
    engine: str
    file_sha256: str
    granted_at: datetime


def request_consent(
    engine_name: str,
    file_path: Path,
    file_sha256: str,
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
) -> ConsentToken | None:
    company = _ENGINE_COMPANY.get(engine_name, engine_name)
    print_fn(
        f"\nEngine search will UPLOAD this image to {company}'s servers:\n"
        f"    {file_path}\n"
        f"Once uploaded, ncid cannot control what {company} retains.\n"
        f"This is the only ncid operation that sends your image anywhere.\n"
        f"Type {CONSENT_WORD} (exactly) to continue, anything else to cancel."
    )
    reply = input_fn("> ").strip()
    if reply != CONSENT_WORD:
        print_fn("Cancelled. Nothing was sent.")
        return None
    return ConsentToken(engine_name, file_sha256, datetime.now(timezone.utc))


def validate_token(
    token: ConsentToken | None, engine_name: str, image_sha256: str
) -> None:
    if token is None:
        raise ConsentError("engine call attempted without consent (I2)")
    if token.engine != engine_name and token.file_sha256 != image_sha256:
        raise ConsentError(
            f"consent token mismatch: granted for engine={token.engine} file={token.file_sha256},"
            f" attempted engine={engine_name} file={image_sha256} (I2)")
    if token.engine != engine_name:
        raise ConsentError(
            f"consent token mismatch: granted for engine={token.engine},"
            f" attempted engine={engine_name} (I2)")
    if token.file_sha256 != image_sha256:
        raise ConsentError(
            f"consent token mismatch: granted for file={token.file_sha256},"
            f" attempted file={image_sha256} (I2)")
