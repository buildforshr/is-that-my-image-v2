from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Literal, Protocol
from urllib.parse import urlparse

import httpx

from ncid.core.models import Candidate

_USAGE = "expected url:https://…, domain:example.com, reddit:r/name or reddit:u/name"


@dataclass(frozen=True)
class SourceSpec:
    kind: Literal["url", "domain", "reddit"]
    value: str


def parse_source_spec(raw: str) -> SourceSpec:
    kind, sep, value = raw.partition(":")
    if not sep or not value:
        raise ValueError(f"invalid source spec {raw!r}; {_USAGE}")
    if kind == "url":
        parsed = urlparse(value)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise ValueError(f"invalid url in source spec {raw!r}; {_USAGE}")
        return SourceSpec("url", value)
    if kind == "domain":
        return SourceSpec("domain", value)
    if kind == "reddit":
        if not (value.startswith("r/") or value.startswith("u/")):
            raise ValueError(f"invalid reddit target {raw!r}; {_USAGE}")
        return SourceSpec("reddit", value)
    raise ValueError(f"unknown source kind {kind!r}; {_USAGE}")


class DownloadRejected(Exception):
    def __init__(self, reason: str, detail: str = "") -> None:
        super().__init__(f"{reason}: {detail}")
        self.reason = reason


async def download_image(
    client: httpx.AsyncClient, url: str, max_bytes: int
) -> bytes:
    try:
        async with client.stream("GET", url) as resp:
            if resp.status_code != 200:
                raise DownloadRejected("http-error", f"{resp.status_code} for {url}")
            ctype = resp.headers.get("content-type", "")
            if not ctype.startswith("image/"):
                raise DownloadRejected("not-image", f"{ctype!r} for {url}")
            chunks: list[bytes] = []
            total = 0
            async for chunk in resp.aiter_bytes():
                total += len(chunk)
                if total > max_bytes:
                    raise DownloadRejected("too-large", f">{max_bytes} bytes for {url}")
                chunks.append(chunk)
            return b"".join(chunks)
    except httpx.HTTPError as e:
        raise DownloadRejected("http-error", f"{e} for {url}") from e


class SourceAdapter(Protocol):
    def iter_candidates(self) -> AsyncIterator[tuple[Candidate, bytes]]: ...
