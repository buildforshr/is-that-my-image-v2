from __future__ import annotations

from ncid.core.models import CandidateHashes, Fingerprint, Tier

# Initial thresholds per spec §5; golden tests in tests/test_matcher.py gate changes.
EXACT_PHASH_MAX = 2
PROBABLE_MIN_MAX = 6
PROBABLE_FAMILY_MAX = 10
PROBABLE_FAMILIES_REQUIRED = 2
POSSIBLE_MIN_MAX = 10

_TIER_RANK = {Tier.EXACT: 0, Tier.PROBABLE: 1, Tier.POSSIBLE: 2}


def hamming(a: int, b: int) -> int:
    return (a ^ b).bit_count()


def match_tier(fp: CandidateHashes, cand: CandidateHashes) -> tuple[Tier | None, int]:
    if fp.sha256 == cand.sha256:
        return Tier.EXACT, 0
    distances = {
        "phash": hamming(fp.phash, cand.phash),
        "dhash": hamming(fp.dhash, cand.dhash),
        "ahash": hamming(fp.ahash, cand.ahash),
        "whash": hamming(fp.whash, cand.whash),
    }
    dmin = min(distances.values())
    if distances["phash"] <= EXACT_PHASH_MAX:
        return Tier.EXACT, distances["phash"]
    close_families = sum(1 for d in distances.values() if d <= PROBABLE_FAMILY_MAX)
    if dmin <= PROBABLE_MIN_MAX and close_families >= PROBABLE_FAMILIES_REQUIRED:
        return Tier.PROBABLE, dmin
    if dmin <= POSSIBLE_MIN_MAX:
        return Tier.POSSIBLE, dmin
    return None, dmin


def best_match(
    fingerprints: list[Fingerprint], cand: CandidateHashes
) -> tuple[Fingerprint, Tier, int] | None:
    best: tuple[Fingerprint, Tier, int] | None = None
    for fp in fingerprints:
        tier, score = match_tier(fp.hashes, cand)
        if tier is None:
            continue
        if best is None or (_TIER_RANK[tier], score) < (_TIER_RANK[best[1]], best[2]):
            best = (fp, tier, score)
    return best
