from __future__ import annotations

import hashlib
import io

import imagehash
from PIL import Image, UnidentifiedImageError

from ncid.core.models import CandidateHashes

# Decompression-bomb guard (spec: adversarial inputs).
Image.MAX_IMAGE_PIXELS = 50_000_000

HASH_SIZE = 8  # 64-bit perceptual hashes


class ImageDecodeError(Exception):
    """Input bytes could not be decoded as a raster image."""


def compute_hashes(data: bytes) -> CandidateHashes:
    sha256 = hashlib.sha256(data).hexdigest()
    try:
        with Image.open(io.BytesIO(data)) as im:
            im = im.convert("RGB")
            return CandidateHashes(
                sha256=sha256,
                phash=int(str(imagehash.phash(im, hash_size=HASH_SIZE)), 16),
                dhash=int(str(imagehash.dhash(im, hash_size=HASH_SIZE)), 16),
                ahash=int(str(imagehash.average_hash(im, hash_size=HASH_SIZE)), 16),
                whash=int(str(imagehash.whash(im, hash_size=HASH_SIZE)), 16),
            )
    except (
        UnidentifiedImageError,
        OSError,
        ValueError,
        SyntaxError,
        Image.DecompressionBombError,
    ) as e:
        raise ImageDecodeError(f"cannot decode image ({len(data)} bytes): {e}") from e
