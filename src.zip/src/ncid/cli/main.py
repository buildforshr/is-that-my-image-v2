from __future__ import annotations

import asyncio
import hashlib
from dataclasses import replace
from pathlib import Path
from typing import Optional

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ncid.core import report as report_mod
from ncid.core.config import db_path, load_config
from ncid.core.fingerprint import ImageDecodeError, compute_hashes
from ncid.core.scan import run_scan, verify_leads
from ncid.core.sources.base import parse_source_spec
from ncid.core.sources.crawler import CrawlerAdapter
from ncid.core.sources.engines.base import request_consent
from ncid.core.sources.engines.google_vision import EngineError, GoogleVisionEngine
from ncid.core.sources.reddit import RedditAdapter, RedditAuthError
from ncid.core.store import Store

app = typer.Typer(help="Privacy-first local detection of your images online.",
                  no_args_is_help=True)
console = Console()


def _store() -> Store:
    return Store(db_path(load_config()))


@app.command()
def fingerprint(
    paths: list[Path],
    label: str = typer.Option("", help="Label shown in listings/reports"),
    no_store_path: bool = typer.Option(False, "--no-store-path",
                                       help="Do not record the file path"),
) -> None:
    """Hash images locally and store fingerprints (never the images)."""
    with _store() as store:
        for path in paths:
            try:
                hashes = compute_hashes(path.read_bytes())
            except (OSError, ImageDecodeError) as e:
                console.print(f"[red]skip {path}: {e}[/red]")
                raise typer.Exit(1)
            fp = store.add_fingerprint(
                label or path.stem, hashes, None if no_store_path else str(path))
            console.print(f"fingerprinted [bold]{fp.label}[/bold] (id {fp.id})")


@app.command("list")
def list_fingerprints() -> None:
    with _store() as store:
        fps = store.list_fingerprints()
    if not fps:
        console.print("No fingerprints stored.")
        return
    table = Table("id", "label", "sha256", "created", "path")
    for fp in fps:
        table.add_row(str(fp.id), fp.label, fp.hashes.sha256[:16] + "…",
                      fp.created_at.date().isoformat(), fp.source_path or "—")
    console.print(table)


@app.command()
def scan(
    source: str = typer.Option(..., help="url:… | domain:… | reddit:r/… | reddit:u/…"),
    engines: str = typer.Option("", help="Comma-separated engines (google). UPLOADS the image after consent."),
    image: Optional[Path] = typer.Option(None, help="Original image file, required for --engines"),
    max_pages: Optional[int] = typer.Option(None),
    max_depth: Optional[int] = typer.Option(None),
    resume: Optional[int] = typer.Option(None, help="Scan run id to resume"),
) -> None:
    """Scan a source for copies of your fingerprinted images. Strict-local by default."""
    cfg = load_config()
    if max_pages is not None:
        cfg = replace(cfg, max_pages=max_pages)
    if max_depth is not None:
        cfg = replace(cfg, max_depth=max_depth)
    if engines and image is None:
        console.print("engine search needs --image PATH"
                      " (ncid stores only hashes, never your images)")
        raise typer.Exit(2)
    try:
        spec = parse_source_spec(source)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(2)
    asyncio.run(_scan_async(cfg, spec, source, engines, image, resume))


async def _scan_async(cfg, spec, raw_source, engines, image, resume_id) -> None:
    with _store() as store:
        if not store.list_fingerprints():
            console.print("No fingerprints. Run `ncid fingerprint` first.")
            raise typer.Exit(1)
        run = (store.get_scan_run(resume_id) if resume_id
               else store.create_scan_run(raw_source))
        if run is None:
            console.print(f"No scan run {resume_id}")
            raise typer.Exit(1)
        headers = {"User-Agent": cfg.user_agent}
        async with httpx.AsyncClient(headers=headers, follow_redirects=True) as client:
            errors: list[str] = []
            if spec.kind in ("url", "domain"):
                start = (spec.value if spec.kind == "url"
                         else f"https://{spec.value}/")
                adapter = CrawlerAdapter(
                    client, cfg, [start], same_domain_only=True,
                    skip_pages=store.seen_page_urls(run.id),
                    on_page=lambda u: (store.mark_page_seen(run.id, u),
                                       setattr(run, "pages_seen", run.pages_seen + 1)),
                    on_error=errors.append)
            else:
                adapter = RedditAdapter(client, cfg, spec.value,
                                        on_error=errors.append)
            try:
                await run_scan(store, adapter, run)
            except RedditAuthError as e:
                console.print(f"[red]{e}[/red]")
                raise typer.Exit(1)
            run.errors += len(errors)
            store.update_scan_run(run)

            if engines:
                await _run_engines(store, client, cfg, run, engines, image)
        console.print(f"Scan {run.id} {run.status}: {run.images_seen} images checked,"
                      f" {len(store.matches_for_run(run.id))} matches,"
                      f" {run.errors} skipped. Run `ncid report`.")


async def _run_engines(store, client, cfg, run, engines, image) -> None:
    for engine_name in [e.strip() for e in engines.split(",") if e.strip()]:
        if engine_name != "google":
            console.print(f"[red]unknown engine {engine_name!r} (v1: google)[/red]")
            raise typer.Exit(2)
        if not cfg.google_api_key:
            console.print("[red]NCID_GOOGLE_API_KEY not set[/red]")
            raise typer.Exit(1)
        data = image.read_bytes()
        token = request_consent("google", image,
                                hashlib.sha256(data).hexdigest())
        if token is None:
            continue  # user declined; strict-local results stand
        try:
            leads = await GoogleVisionEngine(client, cfg.google_api_key
                                             ).search(data, token)
        except EngineError as e:
            console.print(f"[red]{e}[/red]")
            raise typer.Exit(1)
        console.print(f"{len(leads)} leads from google; verifying locally…")
        await verify_leads(store, client, cfg, run, leads)


@app.command("report")
def report_cmd(
    scan: Optional[int] = typer.Option(None, help="Scan run id (default: latest)"),
    format: str = typer.Option("table", help="table | json | md"),
    out: Optional[Path] = typer.Option(None),
) -> None:
    if format not in ("table", "json", "md"):
        console.print(f"[red]invalid --format {format!r}; must be one of: table, json, md[/red]")
        raise typer.Exit(2)
    with _store() as store:
        run = store.get_scan_run(scan) if scan else store.latest_scan_run()
        if run is None:
            console.print("No scans yet.")
            raise typer.Exit(1)
        rep = report_mod.build_report(run, store.matches_for_run(run.id))
    if format == "json":
        text = report_mod.to_json(rep)
    elif format == "md":
        text = report_mod.to_markdown(rep)
    else:
        table = Table("tier", "score", "page", "needs confirmation?")
        for m in rep["matches"]:
            table.add_row(m["tier"], str(m["score"] if m["score"] is not None else "—"),
                          m["page_url"], "yes" if m["needs_confirmation"] else "no")
        console.print(table)
        console.print(f"Skipped/errored candidates: {rep['scan']['errors']}")
        return
    if out:
        out.write_text(text)
        console.print(f"written to {out}")
    else:
        print(text)


@app.command()
def forget(
    fingerprint_id: Optional[int] = typer.Option(None, "--fingerprint"),
    all: bool = typer.Option(False, "--all", help="Delete ALL local ncid data"),
) -> None:
    """Delete fingerprints (I6: deletion is first-class)."""
    with _store() as store:
        if all:
            if not typer.confirm("Delete ALL fingerprints, scans, and matches?"):
                raise typer.Exit(1)
            store.delete_all()
            console.print("All local ncid data deleted.")
        elif fingerprint_id is not None:
            if store.delete_fingerprint(fingerprint_id):
                console.print(f"Fingerprint {fingerprint_id} deleted.")
            else:
                console.print(f"No fingerprint {fingerprint_id}.")
                raise typer.Exit(1)
        else:
            console.print("Pass --fingerprint ID or --all.")
            raise typer.Exit(2)


@app.command("config")
def config_cmd() -> None:
    cfg = load_config()
    console.print(f"data dir: {cfg.data_dir}")
    console.print(f"db: {db_path(cfg)}")
    console.print(f"max_image_bytes={cfg.max_image_bytes} max_pages={cfg.max_pages}"
                  f" max_depth={cfg.max_depth} per_host_delay={cfg.per_host_delay}")
    for key, env in (("google_api_key", "NCID_GOOGLE_API_KEY"),
                     ("reddit_client_id", "NCID_REDDIT_CLIENT_ID"),
                     ("reddit_client_secret", "NCID_REDDIT_CLIENT_SECRET")):
        console.print(f"{env}: {'set' if getattr(cfg, key) else 'not set'}")


if __name__ == "__main__":
    app()
