from datetime import datetime, timezone

from ncid.core.fingerprint import compute_hashes
from ncid.core.models import Match, Tier
from ncid.core.store import Store
from tests.fixture_images import make_image, to_png_bytes


def _store(tmp_path):
    return Store(tmp_path / "test.db")


def test_fingerprint_roundtrip(tmp_path):
    with _store(tmp_path) as s:
        h = compute_hashes(to_png_bytes(make_image(1)))
        fp = s.add_fingerprint("me", h, None)
        assert fp.id is not None
        [loaded] = s.list_fingerprints()
        assert loaded.hashes == h
        assert loaded.source_path is None


def test_forget(tmp_path):
    with _store(tmp_path) as s:
        h = compute_hashes(to_png_bytes(make_image(1)))
        fp = s.add_fingerprint("me", h, "/tmp/x.png")
        assert s.delete_fingerprint(fp.id) is True
        assert s.list_fingerprints() == []
        assert s.delete_fingerprint(999) is False


def test_scan_run_and_matches(tmp_path):
    with _store(tmp_path) as s:
        h = compute_hashes(to_png_bytes(make_image(1)))
        fp = s.add_fingerprint("me", h, None)
        run = s.create_scan_run("url:https://example.com")
        m = Match(fp.id, Tier.EXACT, 0, "https://example.com/i.jpg",
                  "https://example.com/", "page", datetime.now(timezone.utc))
        s.add_match(run.id, m)
        [got] = s.matches_for_run(run.id)
        assert got.tier == Tier.EXACT and got.image_url == m.image_url


def test_no_blob_columns_anywhere(tmp_path):
    """Privacy invariant I4: schema cannot hold image bytes."""
    with _store(tmp_path) as s:
        tables = [r[0] for r in s._conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")]
        assert tables, "schema should exist"
        for t in tables:
            for row in s._conn.execute(f"PRAGMA table_info({t})"):
                assert row[2].upper() != "BLOB", f"{t}.{row[1]} is BLOB"


def test_resume_page_tracking(tmp_path):
    with _store(tmp_path) as s:
        run = s.create_scan_run("domain:example.com")
        s.mark_page_seen(run.id, "https://example.com/a")
        assert s.seen_page_urls(run.id) == {"https://example.com/a"}
