import hashlib
from pathlib import Path

import pytest

from ncid.core.sources.engines.base import (
    ConsentError, ConsentToken, request_consent, validate_token,
)

SHA = hashlib.sha256(b"img").hexdigest()


def _consent(reply: str):
    printed: list[str] = []
    token = request_consent("google", Path("/x/me.png"), SHA,
                            input_fn=lambda prompt: reply, print_fn=printed.append)
    return token, "\n".join(printed)


def test_grants_on_exact_word():
    token, out = _consent("SEND")
    assert token is not None and token.engine == "google"
    assert "/x/me.png" in out and "Google" in out  # names file and destination


@pytest.mark.parametrize("reply", ["send", "yes", "", "y", "SENDD", "SEND extra"])
def test_refuses_everything_else(reply):
    token, _ = _consent(reply)
    assert token is None


@pytest.mark.parametrize("reply", ["SEND ", " SEND", "SEND\n"])
def test_whitespace_padded_send_grants(reply):
    token, _ = _consent(reply)
    assert token is not None and token.engine == "google"


def test_validate_rejects_none_and_mismatch():
    with pytest.raises(ConsentError):
        validate_token(None, "google", SHA)
    token, _ = _consent("SEND")
    with pytest.raises(ConsentError):
        validate_token(token, "tineye", SHA)
    with pytest.raises(ConsentError):
        validate_token(token, "google", "0" * 64)
    validate_token(token, "google", SHA)  # must not raise
