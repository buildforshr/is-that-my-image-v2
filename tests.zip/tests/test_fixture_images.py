from tests.fixture_images import make_image, to_png_bytes, resize_half, crop_10


def test_deterministic():
    assert to_png_bytes(make_image(1)) == to_png_bytes(make_image(1))
    assert to_png_bytes(make_image(1)) != to_png_bytes(make_image(2))


def test_transform_shapes():
    im = make_image(3)
    assert resize_half(im).size == (128, 128)
    assert crop_10(im).size == (231, 231)
