from ncid.core.config import load_config


def test_env_data_dir_and_keys(monkeypatch, tmp_path):
    monkeypatch.setenv("NCID_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("NCID_GOOGLE_API_KEY", "k123")
    monkeypatch.delenv("NCID_REDDIT_CLIENT_ID", raising=False)
    cfg = load_config()
    assert cfg.data_dir == tmp_path
    assert cfg.google_api_key == "k123"
    assert cfg.reddit_client_id is None
    assert cfg.max_image_bytes == 15_000_000


def test_toml_overrides_numbers_not_keys(monkeypatch, tmp_path):
    monkeypatch.setenv("NCID_DATA_DIR", str(tmp_path))
    cfg_dir = tmp_path / "cfg"
    cfg_dir.mkdir()
    (cfg_dir / "config.toml").write_text(
        'max_pages = 50\ngoogle_api_key = "SHOULD_BE_IGNORED"\n')
    monkeypatch.setenv("NCID_CONFIG_DIR", str(cfg_dir))
    monkeypatch.delenv("NCID_GOOGLE_API_KEY", raising=False)
    cfg = load_config()
    assert cfg.max_pages == 50
    assert cfg.google_api_key is None  # I5: keys only from env
