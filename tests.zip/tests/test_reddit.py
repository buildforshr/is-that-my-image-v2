import json

import httpx
import pytest

from ncid.core.config import Config
from ncid.core.sources import reddit as reddit_mod
from ncid.core.sources.reddit import RedditAdapter, RedditAuthError
from tests.fixture_images import make_image, to_png_bytes

IMG = to_png_bytes(make_image(1))

LISTING = {
    "data": {
        "after": None,
        "children": [
            {"data": {
                "title": "direct image post",
                "permalink": "/r/test/comments/1/a/",
                "url_overridden_by_dest": "https://i.example/direct.png",
            }},
            {"data": {
                "title": "preview post",
                "permalink": "/r/test/comments/2/b/",
                "url_overridden_by_dest": "https://example.com/article",
                "preview": {"images": [{"source": {
                    "url": "https://p.example/prev.png&amp;s=sig"}}]},
            }},
        ],
    }
}


def _handler(request: httpx.Request) -> httpx.Response:
    url = str(request.url)
    if "api/v1/access_token" in url:
        assert request.headers.get("authorization", "").startswith("Basic ")
        return httpx.Response(200, json={"access_token": "tok", "expires_in": 3600})
    if "oauth.reddit.com" in url:
        assert request.headers["authorization"] == "Bearer tok"
        return httpx.Response(200, json=LISTING)
    return httpx.Response(200, content=IMG, headers={"content-type": "image/png"})


def _cfg(tmp_path, with_creds=True):
    return Config(
        data_dir=tmp_path, per_host_delay=0.0,
        reddit_client_id="cid" if with_creds else None,
        reddit_client_secret="sec" if with_creds else None,
    )


async def test_yields_direct_and_preview_images(tmp_path):
    async with httpx.AsyncClient(transport=httpx.MockTransport(_handler)) as client:
        adapter = RedditAdapter(client, _cfg(tmp_path), "r/test")
        results = [c async for c in adapter.iter_candidates()]
    urls = {c.image_url for c, _ in results}
    assert "https://i.example/direct.png" in urls
    assert "https://p.example/prev.png&s=sig" in urls  # &amp; unescaped
    assert all(c.page_url.startswith("https://www.reddit.com/r/test/") for c, _ in results)


async def test_missing_creds_raise(tmp_path):
    async with httpx.AsyncClient() as client:
        adapter = RedditAdapter(client, _cfg(tmp_path, with_creds=False), "r/test")
        with pytest.raises(RedditAuthError, match="NCID_REDDIT_CLIENT_ID"):
            _ = [c async for c in adapter.iter_candidates()]


async def test_invalid_creds_message_names_env_vars(tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": "invalid_grant"})

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        adapter = RedditAdapter(client, _cfg(tmp_path), "r/test")
        with pytest.raises(RedditAuthError, match="NCID_REDDIT_CLIENT_ID"):
            _ = [c async for c in adapter.iter_candidates()]


LISTING_GALLERY = {
    "data": {
        "after": None,
        "children": [
            {"data": {
                "title": "gallery post",
                "permalink": "/r/test/comments/3/c/",
                "media_metadata": {
                    "abc": {"s": {"u": "https://g.example/gal.png&amp;s=x"}},
                },
            }},
        ],
    }
}


def _gallery_handler(request: httpx.Request) -> httpx.Response:
    url = str(request.url)
    if "api/v1/access_token" in url:
        return httpx.Response(200, json={"access_token": "tok", "expires_in": 3600})
    if "oauth.reddit.com" in url:
        return httpx.Response(200, json=LISTING_GALLERY)
    return httpx.Response(200, content=IMG, headers={"content-type": "image/png"})


async def test_extracts_gallery_images(tmp_path):
    async with httpx.AsyncClient(transport=httpx.MockTransport(_gallery_handler)) as client:
        adapter = RedditAdapter(client, _cfg(tmp_path), "r/test")
        results = [c async for c in adapter.iter_candidates()]
    urls = {c.image_url for c, _ in results}
    assert "https://g.example/gal.png&s=x" in urls  # &amp; unescaped


LISTING_PAGE1 = {
    "data": {
        "after": "t3_x",
        "children": [
            {"data": {
                "title": "page1 post",
                "permalink": "/r/test/comments/1/a/",
                "url_overridden_by_dest": "https://i.example/page1.png",
            }},
        ],
    }
}
LISTING_PAGE2 = {
    "data": {
        "after": None,
        "children": [
            {"data": {
                "title": "page2 post",
                "permalink": "/r/test/comments/2/b/",
                "url_overridden_by_dest": "https://i.example/page2.png",
            }},
        ],
    }
}


def _paginated_handler(request: httpx.Request) -> httpx.Response:
    url = str(request.url)
    if "api/v1/access_token" in url:
        return httpx.Response(200, json={"access_token": "tok", "expires_in": 3600})
    if "oauth.reddit.com" in url:
        after = request.url.params.get("after")
        if after is None:
            return httpx.Response(200, json=LISTING_PAGE1)
        assert after == "t3_x"  # second request must carry the first page's cursor
        return httpx.Response(200, json=LISTING_PAGE2)
    return httpx.Response(200, content=IMG, headers={"content-type": "image/png"})


async def test_paginates_with_after_cursor(tmp_path):
    async with httpx.AsyncClient(transport=httpx.MockTransport(_paginated_handler)) as client:
        adapter = RedditAdapter(client, _cfg(tmp_path), "r/test")
        results = [c async for c in adapter.iter_candidates()]
    urls = {c.image_url for c, _ in results}
    assert "https://i.example/page1.png" in urls
    assert "https://i.example/page2.png" in urls


async def test_429_retry_bounded(tmp_path, monkeypatch):
    # Keep the retry-backoff sleep out of the test's critical path.
    monkeypatch.setattr(reddit_mod, "_RETRY_DELAY", 0.0)

    def handler(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        if "api/v1/access_token" in url:
            return httpx.Response(200, json={"access_token": "tok", "expires_in": 3600})
        if "oauth.reddit.com" in url:
            return httpx.Response(429)
        return httpx.Response(200, content=IMG, headers={"content-type": "image/png"})

    errors = []
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        adapter = RedditAdapter(client, _cfg(tmp_path), "r/test", on_error=errors.append)
        results = [c async for c in adapter.iter_candidates()]
    assert results == []
    give_ups = [e for e in errors if e.startswith("gave up after 429 retry")]
    assert len(give_ups) == 1
