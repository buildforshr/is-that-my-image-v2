import json
from pathlib import Path

from typer.testing import CliRunner

from ncid.cli.main import app
from tests.fixture_images import make_image, to_png_bytes

runner = CliRunner()


def _write_image(tmp_path, seed=1) -> Path:
    p = tmp_path / f"img{seed}.png"
    p.write_bytes(to_png_bytes(make_image(seed)))
    return p


def test_fingerprint_and_list(tmp_path, data_dir):
    img = _write_image(tmp_path)
    result = runner.invoke(app, ["fingerprint", str(img), "--label", "me"])
    assert result.exit_code == 0, result.output
    result = runner.invoke(app, ["list"])
    assert "me" in result.output


def test_fingerprint_no_store_path(tmp_path, data_dir):
    img = _write_image(tmp_path)
    runner.invoke(app, ["fingerprint", str(img), "--no-store-path"])
    result = runner.invoke(app, ["list"])
    assert str(img) not in result.output


def test_forget_all_requires_confirmation(tmp_path, data_dir):
    img = _write_image(tmp_path)
    runner.invoke(app, ["fingerprint", str(img)])
    result = runner.invoke(app, ["forget", "--all"], input="n\n")
    assert result.exit_code == 1
    # Declined: fingerprint (labelled by file stem, no --label given) still present.
    assert img.stem in runner.invoke(app, ["list"]).output
    result = runner.invoke(app, ["forget", "--all"], input="y\n")
    assert result.exit_code == 0
    assert "no fingerprints" in runner.invoke(app, ["list"]).output.lower()


def test_engines_without_image_errors(data_dir):
    result = runner.invoke(app, ["scan", "--source", "url:https://x",
                                 "--engines", "google"])
    assert result.exit_code == 2
    assert "--image" in result.output


def test_scan_invalid_source_errors_loud(data_dir):
    result = runner.invoke(app, ["scan", "--source", "not-a-valid-spec"])
    assert result.exit_code == 2
    assert "expected url:" in result.output


def test_report_invalid_format_errors_loud(data_dir):
    result = runner.invoke(app, ["report", "--format", "jsom"])
    assert result.exit_code == 2
    assert "table" in result.output
    assert "json" in result.output
    assert "md" in result.output


def test_scan_and_report_against_local_server(tmp_path, data_dir, httpserver):
    from tests.test_crawler import _serve_site
    _serve_site(httpserver)
    img = tmp_path / "orig.png"
    img.write_bytes(to_png_bytes(make_image(1)))
    runner.invoke(app, ["fingerprint", str(img)])
    result = runner.invoke(app, ["scan", "--source",
                                 f"url:{httpserver.url_for('/')}"])
    assert result.exit_code == 0, result.output
    result = runner.invoke(app, ["report", "--format", "json"])
    report = json.loads(result.output)
    assert report["counts"]["exact"] >= 1
