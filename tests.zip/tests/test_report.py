import json
from datetime import datetime, timezone

from ncid.core.models import Match, ScanRun, Tier
from ncid.core.report import build_report, to_json, to_markdown

NOW = datetime.now(timezone.utc)
RUN = ScanRun(1, "url:https://x", NOW, NOW, "finished", 5, 20, 2)
MATCHES = [
    Match(1, Tier.EXACT, 0, "https://x/a.jpg", "https://x/p", "P", NOW),
    Match(1, Tier.POSSIBLE, 9, "https://x/b.jpg", "https://x/q", None, NOW),
    Match(None, Tier.UNVERIFIED_LEAD, None, "", "https://y/lead", None, NOW),
]


def test_build_report_counts_and_flags():
    rep = build_report(RUN, MATCHES)
    assert rep["counts"] == {"exact": 1, "probable": 0, "possible": 1,
                             "unverified-lead": 1, "errors": 2}
    flags = {m["image_url"]: m["needs_confirmation"] for m in rep["matches"]}
    assert flags["https://x/a.jpg"] is False
    assert flags["https://x/b.jpg"] is True


def test_json_roundtrips():
    parsed = json.loads(to_json(build_report(RUN, MATCHES)))
    assert parsed["scan"]["errors"] == 2


def test_markdown_labels():
    md = to_markdown(build_report(RUN, MATCHES))
    assert "needs human confirmation" in md
    assert "Skipped/errored candidates: 2" in md
    assert "https://x/a.jpg" in md
