import base64
import hashlib
import json
from datetime import datetime, timezone

import httpx
import pytest
from pytest_httpserver import HTTPServer

from ncid.core.config import Config
from ncid.core.fingerprint import compute_hashes
from ncid.core.models import Tier
from ncid.core.scan import verify_leads
from ncid.core.sources.engines.base import ConsentError, ConsentToken
from ncid.core.sources.engines.google_vision import EngineError, GoogleVisionEngine, Lead
from ncid.core.store import Store
from tests.fixture_images import make_image, to_png_bytes
from tests.test_crawler import _serve_site

IMG = b"fake-image-bytes"
TOKEN = ConsentToken("google", hashlib.sha256(IMG).hexdigest(),
                     datetime.now(timezone.utc))

RESPONSE = {"responses": [{"webDetection": {
    "fullMatchingImages": [{"url": "https://a.example/full.jpg"}],
    "partialMatchingImages": [{"url": "https://b.example/part.jpg"}],
    "pagesWithMatchingImages": [{"url": "https://c.example/page"}],
}}]}


def _handler(request: httpx.Request) -> httpx.Response:
    body = json.loads(request.content)
    sent = body["requests"][0]["image"]["content"]
    assert base64.b64decode(sent) == IMG
    assert body["requests"][0]["features"][0]["type"] == "WEB_DETECTION"
    return httpx.Response(200, json=RESPONSE)


async def test_search_maps_leads():
    async with httpx.AsyncClient(transport=httpx.MockTransport(_handler)) as client:
        leads = await GoogleVisionEngine(client, "key").search(IMG, TOKEN)
    assert Lead(page_url="https://c.example/page", image_url=None) in leads
    assert Lead(page_url=None, image_url="https://a.example/full.jpg") in leads
    assert Lead(page_url=None, image_url="https://b.example/part.jpg") in leads


async def test_search_requires_valid_token():
    async with httpx.AsyncClient() as client:
        with pytest.raises(ConsentError):
            await GoogleVisionEngine(client, "key").search(b"other-bytes", TOKEN)


async def test_http_error_is_actionable():
    async with httpx.AsyncClient(transport=httpx.MockTransport(
            lambda req: httpx.Response(403, json={"error": {"message": "quota"}}))) as client:
        with pytest.raises(EngineError, match="403"):
            await GoogleVisionEngine(client, "key").search(IMG, TOKEN)


async def test_embedded_error_on_200_is_actionable():
    # Vision API can return HTTP 200 with the real failure nested in
    # responses[0].error -- must not be silently read as "zero leads".
    body = {"responses": [{"error": {"code": 7, "message": "Vision API not enabled"}}]}
    async with httpx.AsyncClient(transport=httpx.MockTransport(
            lambda req: httpx.Response(200, json=body))) as client:
        with pytest.raises(EngineError, match="not enabled"):
            await GoogleVisionEngine(client, "key").search(IMG, TOKEN)


async def test_verify_leads_confirms_and_flags(httpserver: HTTPServer, tmp_path):
    _serve_site(httpserver)
    httpserver.expect_request("/gone").respond_with_data("nope", status=404)
    with Store(tmp_path / "t.db") as store:
        store.add_fingerprint("me", compute_hashes(to_png_bytes(make_image(1))), None)
        run = store.create_scan_run("engine")
        cfg = Config(data_dir=tmp_path, per_host_delay=0.0)
        leads = [
            Lead(page_url=httpserver.url_for("/"), image_url=None),      # page with real copy
            Lead(page_url=None, image_url=httpserver.url_for("/gone")),  # dead lead
        ]
        async with httpx.AsyncClient() as client:
            await verify_leads(store, client, cfg, run, leads)
        tiers = {m.tier for m in store.matches_for_run(run.id)}
        assert Tier.EXACT in tiers            # confirmed locally via crawl
        assert Tier.UNVERIFIED_LEAD in tiers  # dead lead surfaced, clearly separated


async def test_verify_leads_undecodable_image_counts_error_and_flags_lead(
    httpserver: HTTPServer, tmp_path,
):
    # image/* content-type but bytes that fail decode -- exercises the
    # compute_hashes-raises path through the try/finally around `data` (I3).
    httpserver.expect_request("/garbage.png").respond_with_data(
        b"garbage", content_type="image/png")
    with Store(tmp_path / "t.db") as store:
        run = store.create_scan_run("engine")
        cfg = Config(data_dir=tmp_path, per_host_delay=0.0)
        bad_url = httpserver.url_for("/garbage.png")
        leads = [Lead(page_url=None, image_url=bad_url)]
        async with httpx.AsyncClient() as client:
            result = await verify_leads(store, client, cfg, run, leads)
        assert result.errors == 1
        matches = store.matches_for_run(run.id)
        assert len(matches) == 1
        assert matches[0].tier == Tier.UNVERIFIED_LEAD
        assert matches[0].image_url == bad_url


async def test_verify_leads_page_lead_not_confirmed_by_unrelated_page(
    httpserver: HTTPServer, tmp_path,
):
    """A match found on a page OTHER than the lead's own page must not
    confirm the lead (regression: previously any match found anywhere
    during the verification crawl confirmed the lead, so a dead lead page
    that merely links to an unrelated real copy would wrongly "confirm").

    The lead page itself has no matching image, but links to a page that
    does. With the verification crawl pinned to max_depth=0, that link is
    never followed, so the lead correctly lands as unverified-lead."""
    matching = to_png_bytes(make_image(1))
    unrelated = to_png_bytes(make_image(2))
    httpserver.expect_request("/robots.txt").respond_with_data(
        "User-agent: *\nAllow: /\n")
    httpserver.expect_request("/lead").respond_with_data(
        '<html><body><img src="/img/unrelated.png">'
        '<a href="/elsewhere">elsewhere</a></body></html>',
        content_type="text/html")
    httpserver.expect_request("/elsewhere").respond_with_data(
        '<html><body><img src="/img/matching.png"></body></html>',
        content_type="text/html")
    httpserver.expect_request("/img/unrelated.png").respond_with_data(
        unrelated, content_type="image/png")
    httpserver.expect_request("/img/matching.png").respond_with_data(
        matching, content_type="image/png")
    with Store(tmp_path / "t.db") as store:
        store.add_fingerprint("me", compute_hashes(matching), None)
        run = store.create_scan_run("engine")
        cfg = Config(data_dir=tmp_path, per_host_delay=0.0)
        lead_url = httpserver.url_for("/lead")
        leads = [Lead(page_url=lead_url, image_url=None)]
        async with httpx.AsyncClient() as client:
            await verify_leads(store, client, cfg, run, leads)
        matches = store.matches_for_run(run.id)
        assert len(matches) == 1
        assert matches[0].tier == Tier.UNVERIFIED_LEAD
        assert matches[0].page_url == lead_url
