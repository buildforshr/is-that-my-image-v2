"""Spec §3 invariants. These tests are the contract; never weaken them."""
import json

import httpx
from typer.testing import CliRunner

from ncid.cli.main import app
from ncid.core.config import Config
from ncid.core.fingerprint import compute_hashes
from ncid.core.scan import run_scan
from ncid.core.sources.crawler import CrawlerAdapter
from ncid.core.store import Store
from tests.fixture_images import make_image, to_png_bytes
from tests.test_crawler import _serve_site

runner = CliRunner()


async def test_i1_no_outbound_image_or_hash_data(httpserver, tmp_path):
    """Strict-local scan: every outbound request is a bodyless GET to the
    target host; no request contains fingerprint hash material."""
    _serve_site(httpserver)
    original = to_png_bytes(make_image(1))
    hashes = compute_hashes(original)
    hash_material = {hashes.sha256, f"{hashes.phash:016x}"}

    recorded: list[httpx.Request] = []

    class RecordingTransport(httpx.AsyncHTTPTransport):
        async def handle_async_request(self, request):
            recorded.append(request)
            return await super().handle_async_request(request)

    with Store(tmp_path / "t.db") as store:
        store.add_fingerprint("me", hashes, None)
        run = store.create_scan_run("test")
        cfg = Config(data_dir=tmp_path, per_host_delay=0.0)
        async with httpx.AsyncClient(transport=RecordingTransport()) as client:
            adapter = CrawlerAdapter(client, cfg, [httpserver.url_for("/")],
                                     same_domain_only=True)
            await run_scan(store, adapter, run)

    assert recorded, "scan should have made requests"
    allowed_host = httpserver.url_for("/").split("//")[1].rstrip("/")
    for req in recorded:
        assert req.method == "GET"
        assert req.url.netloc.decode() == allowed_host
        assert not req.content
        serialized = str(req.url) + str(dict(req.headers))
        for secret in hash_material:
            assert secret not in serialized


async def test_i3_no_candidate_files_written(httpserver, tmp_path, data_dir):
    """Nothing lands on disk during a scan except the SQLite DB."""
    _serve_site(httpserver)
    with Store(data_dir / "ncid.db") as store:
        store.add_fingerprint("me", compute_hashes(to_png_bytes(make_image(1))), None)
        run = store.create_scan_run("test")
        cfg = Config(data_dir=data_dir, per_host_delay=0.0)
        async with httpx.AsyncClient() as client:
            adapter = CrawlerAdapter(client, cfg, [httpserver.url_for("/")],
                                     same_domain_only=True)
            await run_scan(store, adapter, run)
    files = {p.name for p in data_dir.rglob("*") if p.is_file()}
    assert files <= {"ncid.db", "ncid.db-journal", "ncid.db-wal", "ncid.db-shm"}


def test_i4_db_values_contain_no_image_bytes(tmp_path, data_dir, httpserver):
    """Every stored value across all tables is short text/numbers — nothing
    resembling encoded image data."""
    _serve_site(httpserver)
    img = tmp_path / "orig.png"
    img.write_bytes(to_png_bytes(make_image(1)))
    runner.invoke(app, ["fingerprint", str(img)])
    runner.invoke(app, ["scan", "--source", f"url:{httpserver.url_for('/')}"])
    import sqlite3
    conn = sqlite3.connect(data_dir / "ncid.db")
    for (table,) in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall():
        for row in conn.execute(f"SELECT * FROM {table}"):
            for value in row:
                assert not isinstance(value, bytes), f"BLOB value in {table}"
                if isinstance(value, str):
                    assert len(value) < 2048, f"suspiciously large text in {table}"


def test_i2_engine_unreachable_without_consent(tmp_path, data_dir, monkeypatch):
    """Declining the consent prompt means no engine request is attempted.

    Asserting only the "Cancelled." string is not enough: it prints
    unconditionally from request_consent() regardless of whether the caller
    honors the returned None. This test instead records every request the
    CLI's own httpx client makes (same pattern as test_i1) and asserts none
    reach vision.googleapis.com or any host outside the (unreachable) scan
    target -- so a mutation that drops the `if token is None: continue` guard
    in cli/main.py's _run_engines is actually caught.
    """
    monkeypatch.setenv("NCID_GOOGLE_API_KEY", "k")
    img = tmp_path / "orig.png"
    img.write_bytes(to_png_bytes(make_image(1)))
    runner.invoke(app, ["fingerprint", str(img)])

    recorded: list[httpx.Request] = []

    class RecordingTransport(httpx.AsyncHTTPTransport):
        async def handle_async_request(self, request):
            recorded.append(request)
            return await super().handle_async_request(request)

    class RecordingAsyncClient(httpx.AsyncClient):
        def __init__(self, *args, **kwargs):
            kwargs.setdefault("transport", RecordingTransport())
            super().__init__(*args, **kwargs)

    # cli/main.py does `import httpx` then `httpx.AsyncClient(...)`, so
    # patching the attribute on the httpx module intercepts the client it
    # constructs for this scan without touching any other test.
    monkeypatch.setattr(httpx, "AsyncClient", RecordingAsyncClient)

    result = runner.invoke(
        app,
        ["scan", "--source", "url:https://127.0.0.1:1/none",
         "--engines", "google", "--image", str(img)],
        input="no\n",
    )

    # Engine declined -> no EngineError, no upload attempt; scan completes cleanly.
    assert result.exit_code == 0, result.output
    assert result.exception is None, repr(result.exception)
    assert "Cancelled. Nothing was sent." in result.output

    contacted_hosts = {req.url.host for req in recorded}
    assert "vision.googleapis.com" not in contacted_hosts
    # Only the (unreachable) scan target may have been contacted -- no other
    # host, and specifically no engine host, was ever dialed.
    assert contacted_hosts <= {"127.0.0.1"}, f"unexpected outbound hosts: {contacted_hosts}"


def test_i2_accept_engine_lead_verified_end_to_end(tmp_path, data_dir, httpserver, monkeypatch):
    """Full ACCEPT path, proven through the CLI: consent granted -> engine
    contacted -> the engine's lead is fed back through the local crawler for
    verification (spec §6.3), not trusted on its own.

    The seed page served at `/` has no images and no links, so the plain
    strict-local crawl finds zero matches on its own. The (mocked) engine
    response points at `/leadpage`, a page unreachable from the seed, which
    does carry the fingerprinted image. A confirmed match can therefore only
    appear via the engine -> verify_leads wiring, proving it end-to-end.
    """
    matching = to_png_bytes(make_image(1))
    httpserver.expect_request("/robots.txt").respond_with_data(
        "User-agent: *\nAllow: /\n")
    httpserver.expect_request("/").respond_with_data(
        "<html><title>Home</title><body>nothing to see here</body></html>",
        content_type="text/html")
    httpserver.expect_request("/leadpage").respond_with_data(
        '<html><body><img src="/img/match.png"></body></html>',
        content_type="text/html")
    httpserver.expect_request("/img/match.png").respond_with_data(
        matching, content_type="image/png")

    img = tmp_path / "orig.png"
    img.write_bytes(matching)
    runner.invoke(app, ["fingerprint", str(img)])

    monkeypatch.setenv("NCID_GOOGLE_API_KEY", "k")

    lead_page_url = httpserver.url_for("/leadpage")
    canned_vision_response = {"responses": [{"webDetection": {
        "pagesWithMatchingImages": [{"url": lead_page_url}],
    }}]}

    recorded: list[httpx.Request] = []

    class EngineMockingTransport(httpx.AsyncHTTPTransport):
        """Vision requests get a canned response; everything else (the
        local httpserver) passes through to the real network, same as
        RecordingTransport above but with one host short-circuited."""
        async def handle_async_request(self, request):
            recorded.append(request)
            if request.url.host == "vision.googleapis.com":
                return httpx.Response(200, json=canned_vision_response)
            return await super().handle_async_request(request)

    class MockingAsyncClient(httpx.AsyncClient):
        def __init__(self, *args, **kwargs):
            kwargs.setdefault("transport", EngineMockingTransport())
            super().__init__(*args, **kwargs)

    monkeypatch.setattr(httpx, "AsyncClient", MockingAsyncClient)

    result = runner.invoke(
        app,
        ["scan", "--source", f"url:{httpserver.url_for('/')}",
         "--engines", "google", "--image", str(img)],
        input="SEND\n",
    )
    assert result.exit_code == 0, result.output
    assert result.exception is None, repr(result.exception)

    vision_hits = [r for r in recorded if r.url.host == "vision.googleapis.com"]
    assert vision_hits, "consent honored: engine endpoint should have been contacted"

    report = json.loads(runner.invoke(app, ["report", "--format", "json"]).output)
    tiers = {m["tier"] for m in report["matches"]}
    assert tiers & {"exact", "unverified-lead"}, report
    # The lead page carries the real fingerprinted image and is reachable
    # only via verify_leads, so it must resolve to a confirmed EXACT match.
    assert "exact" in tiers, report
