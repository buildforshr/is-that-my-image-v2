import io

import pytest
from PIL import Image

from ncid.core.fingerprint import ImageDecodeError, compute_hashes
from tests.fixture_images import make_image, to_jpeg_bytes, to_png_bytes


def test_stable_hashes():
    data = to_png_bytes(make_image(1))
    h1, h2 = compute_hashes(data), compute_hashes(data)
    assert h1 == h2
    assert len(h1.sha256) == 64
    assert 0 <= h1.phash < 2**64


def test_format_reencode_changes_sha_not_much_phash():
    im = make_image(1)
    png, jpg = compute_hashes(to_png_bytes(im)), compute_hashes(to_jpeg_bytes(im))
    assert png.sha256 != jpg.sha256
    assert (png.phash ^ jpg.phash).bit_count() <= 2


def test_garbage_raises():
    with pytest.raises(ImageDecodeError):
        compute_hashes(b"not an image at all")


def test_zero_bytes_raises():
    with pytest.raises(ImageDecodeError):
        compute_hashes(b"")


def test_decompression_bomb_raises():
    # 12000x9000 = 108,000,000 pixels, > 2x compute_hashes' 50M-pixel guard,
    # so PIL raises DecompressionBombError (not just a warning) on decode.
    # Image.new is not subject to MAX_IMAGE_PIXELS -- only decode is -- so
    # building and encoding this image here does not trip the guard.
    bomb = Image.new("RGB", (12000, 9000), (10, 20, 30))
    buf = io.BytesIO()
    bomb.save(buf, format="PNG")
    with pytest.raises(ImageDecodeError):
        compute_hashes(buf.getvalue())
