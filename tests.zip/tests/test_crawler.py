import httpx
from pytest_httpserver import HTTPServer

from ncid.core.config import Config
from ncid.core.sources import crawler as crawler_mod
from ncid.core.sources.crawler import CrawlerAdapter
from tests.fixture_images import make_image, to_png_bytes

IMG = to_png_bytes(make_image(1))


def _serve_site(server: HTTPServer, robots: str = "User-agent: *\nAllow: /\n"):
    server.expect_request("/robots.txt").respond_with_data(robots)
    server.expect_request("/").respond_with_data(
        '<html><title>Home</title><body>'
        '<img src="/img/a.png">'
        '<img srcset="/img/b.png 1x, /img/b2x.png 2x">'
        '<meta property="og:image" content="/img/og.png">'
        '<a href="/page2">next</a>'
        '<a href="/secret/page">secret</a></body></html>',
        content_type="text/html")
    server.expect_request("/page2").respond_with_data(
        '<html><body><img src="/img/c.png"></body></html>',
        content_type="text/html")
    server.expect_request("/secret/page").respond_with_data(
        '<html><body><img src="/img/secret.png"></body></html>',
        content_type="text/html")
    for name in ("a", "b", "b2x", "og", "c", "secret"):
        server.expect_request(f"/img/{name}.png").respond_with_data(
            IMG, content_type="image/png")


def _cfg(tmp_path):
    return Config(data_dir=tmp_path, per_host_delay=0.0, max_pages=10, max_depth=2)


async def _collect(adapter):
    return [c async for c in adapter.iter_candidates()]


async def test_extracts_images_and_follows_links(httpserver: HTTPServer, tmp_path):
    _serve_site(httpserver)
    async with httpx.AsyncClient() as client:
        adapter = CrawlerAdapter(client, _cfg(tmp_path),
                                 [httpserver.url_for("/")], same_domain_only=True)
        results = await _collect(adapter)
    image_urls = {c.image_url for c, _ in results}
    assert httpserver.url_for("/img/a.png") in image_urls
    assert httpserver.url_for("/img/b.png") in image_urls      # srcset first entry
    assert httpserver.url_for("/img/og.png") in image_urls     # og:image
    assert httpserver.url_for("/img/c.png") in image_urls      # followed link
    assert all(isinstance(b, bytes) and b for _, b in results)


async def test_robots_disallow_honored(httpserver: HTTPServer, tmp_path):
    _serve_site(httpserver, robots="User-agent: *\nDisallow: /secret/\n")
    errors = []
    async with httpx.AsyncClient() as client:
        adapter = CrawlerAdapter(client, _cfg(tmp_path),
                                 [httpserver.url_for("/")], same_domain_only=True,
                                 on_error=errors.append)
        results = await _collect(adapter)
    assert httpserver.url_for("/img/secret.png") not in {c.image_url for c, _ in results}
    secret_page = httpserver.url_for("/secret/page")
    assert any("robots disallowed" in e and secret_page in e for e in errors)


async def test_max_pages_cap(httpserver: HTTPServer, tmp_path):
    _serve_site(httpserver)
    cfg = Config(data_dir=tmp_path, per_host_delay=0.0, max_pages=1, max_depth=2)
    pages = []
    async with httpx.AsyncClient() as client:
        adapter = CrawlerAdapter(client, cfg, [httpserver.url_for("/")],
                                 same_domain_only=True, on_page=pages.append)
        await _collect(adapter)
    assert len(pages) == 1


async def test_429_retry_bounded(httpserver: HTTPServer, tmp_path, monkeypatch):
    # Keep the retry-backoff sleep out of the test's critical path.
    monkeypatch.setattr(crawler_mod, "_RETRY_DELAY", 0.0)
    httpserver.expect_request("/robots.txt").respond_with_data("User-agent: *\nAllow: /\n")
    httpserver.expect_request("/always429").respond_with_data("", status=429)
    errors = []
    async with httpx.AsyncClient() as client:
        adapter = CrawlerAdapter(client, _cfg(tmp_path),
                                 [httpserver.url_for("/always429")],
                                 same_domain_only=True, on_error=errors.append)
        results = await _collect(adapter)
    assert results == []
    give_ups = [e for e in errors if e.startswith("gave up after 429 retry")]
    assert len(give_ups) == 1
    assert httpserver.url_for("/always429") in give_ups[0]


async def test_multiple_seeds_different_hosts_all_attempted(httpserver: HTTPServer, tmp_path):
    _serve_site(httpserver)
    # Port 1 requires root and nothing listens there in test environments, so this
    # seed fails fast with a connection error -- proving it was attempted rather
    # than silently dropped by a same-domain check anchored to the first seed only.
    unreachable_seed = "http://127.0.0.1:1/page"
    errors = []
    async with httpx.AsyncClient() as client:
        adapter = CrawlerAdapter(client, _cfg(tmp_path),
                                 [httpserver.url_for("/"), unreachable_seed],
                                 same_domain_only=True, on_error=errors.append)
        await _collect(adapter)
    assert any(unreachable_seed in e for e in errors)
    assert not any("same-domain skip" in e and unreachable_seed in e for e in errors)
