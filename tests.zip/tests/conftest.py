import pytest


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "ncid-data"
    d.mkdir()
    monkeypatch.setenv("NCID_DATA_DIR", str(d))
    return d
