from datetime import datetime, timezone

from ncid.core.models import Candidate, CandidateHashes, Fingerprint, Match, Tier


def test_tier_values():
    assert Tier.EXACT.value == "exact"
    assert Tier.UNVERIFIED_LEAD.value == "unverified-lead"


def test_frozen():
    c = Candidate(image_url="https://x/i.jpg", page_url="https://x/p")
    try:
        c.image_url = "other"
        assert False, "should be frozen"
    except AttributeError:
        pass
