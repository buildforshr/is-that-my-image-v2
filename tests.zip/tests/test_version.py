import ncid


def test_version():
    assert ncid.__version__ == "0.1.0"
