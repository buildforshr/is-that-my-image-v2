import asyncio

import pytest

from ncid.core.fingerprint import compute_hashes
from ncid.core.models import Candidate, Tier
from ncid.core.scan import run_scan
from ncid.core.store import Store
from tests.fixture_images import make_image, to_png_bytes


class FakeAdapter:
    def __init__(self, items):
        self._items = items

    async def iter_candidates(self):
        for item in self._items:
            yield item


class BlockingAdapter:
    """Yields the given items, then hangs forever -- lets a test drive
    cancellation deterministically instead of racing a real long scan."""

    def __init__(self, items):
        self._items = items

    async def iter_candidates(self):
        for item in self._items:
            yield item
        await asyncio.Event().wait()


async def test_scan_records_matches_and_errors(tmp_path):
    with Store(tmp_path / "t.db") as store:
        original = to_png_bytes(make_image(1))
        store.add_fingerprint("me", compute_hashes(original), None)
        run = store.create_scan_run("url:test")
        adapter = FakeAdapter([
            (Candidate("https://x/copy.png", "https://x/p1", "t1"), original),
            (Candidate("https://x/other.png", "https://x/p2", "t2"),
             to_png_bytes(make_image(99))),
            (Candidate("https://x/broken.png", "https://x/p3", "t3"), b"garbage"),
        ])
        result = await run_scan(store, adapter, run)
        assert result.status == "finished"
        assert result.images_seen == 3
        assert result.errors == 1
        matches = store.matches_for_run(run.id)
        assert len(matches) == 1
        assert matches[0].tier == Tier.EXACT
        assert matches[0].image_url == "https://x/copy.png"


async def test_scan_cancellation_persists_interrupted(tmp_path):
    with Store(tmp_path / "t.db") as store:
        run = store.create_scan_run("url:test")
        original = to_png_bytes(make_image(1))
        adapter = BlockingAdapter([
            (Candidate("https://x/1.png", "https://x/p1", "t1"), original),
            (Candidate("https://x/2.png", "https://x/p2", "t2"), original),
        ])

        task = asyncio.create_task(run_scan(store, adapter, run))
        await asyncio.sleep(0.05)
        task.cancel()

        with pytest.raises(asyncio.CancelledError):
            await task

        reloaded = store.get_scan_run(run.id)
        assert reloaded is not None
        assert reloaded.status == "interrupted"


async def test_scan_checkpoints_progress_every_25(tmp_path, monkeypatch):
    with Store(tmp_path / "t.db") as store:
        run = store.create_scan_run("url:test")
        original = to_png_bytes(make_image(1))
        adapter = FakeAdapter([
            (Candidate(f"https://x/{i}.png", "https://x/p", "t"), original)
            for i in range(30)
        ])

        real_update = store.update_scan_run
        checkpoint_calls: list[int] = []

        def spy(r):
            checkpoint_calls.append(r.images_seen)
            return real_update(r)

        monkeypatch.setattr(store, "update_scan_run", spy)

        result = await run_scan(store, adapter, run)

        assert len(checkpoint_calls) >= 2  # mid-scan checkpoint at 25 + final
        assert result.status == "finished"
        assert result.images_seen == 30

        reloaded = store.get_scan_run(run.id)
        assert reloaded is not None
        assert reloaded.images_seen == 30
        assert reloaded.status == "finished"
