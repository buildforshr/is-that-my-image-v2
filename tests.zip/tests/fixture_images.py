"""Deterministic synthetic images. Never real photographs."""
import io
import random

from PIL import Image, ImageDraw


def make_image(seed: int, size: tuple[int, int] = (256, 256)) -> Image.Image:
    rng = random.Random(seed)
    im = Image.new("RGB", size, tuple(rng.randrange(256) for _ in range(3)))
    draw = ImageDraw.Draw(im)
    for _ in range(40):
        x0, y0 = rng.randrange(size[0]), rng.randrange(size[1])
        x1, y1 = x0 + rng.randrange(10, 80), y0 + rng.randrange(10, 80)
        color = tuple(rng.randrange(256) for _ in range(3))
        if rng.random() < 0.5:
            draw.ellipse([x0, y0, x1, y1], fill=color)
        else:
            draw.rectangle([x0, y0, x1, y1], fill=color)
    return im


def to_png_bytes(im: Image.Image) -> bytes:
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()


def to_jpeg_bytes(im: Image.Image, quality: int = 90) -> bytes:
    buf = io.BytesIO()
    im.save(buf, format="JPEG", quality=quality)
    return buf.getvalue()


def resize_half(im: Image.Image) -> Image.Image:
    return im.resize((im.width // 2, im.height // 2))


def reencode_q60(im: Image.Image) -> bytes:
    return to_jpeg_bytes(im, quality=60)


def watermark(im: Image.Image) -> Image.Image:
    out = im.copy()
    draw = ImageDraw.Draw(out)
    draw.text((10, out.height - 20), "watermark", fill=(255, 255, 255))
    return out


def crop_10(im: Image.Image) -> Image.Image:
    dx, dy = int(im.width * 0.05), int(im.height * 0.05)
    return im.crop((dx, dy, im.width - dx - 1, im.height - dy - 1))
