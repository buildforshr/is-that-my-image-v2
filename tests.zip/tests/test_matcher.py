from datetime import datetime, timezone

from ncid.core.fingerprint import compute_hashes
from ncid.core.matcher import best_match, hamming, match_tier
from ncid.core.models import CandidateHashes, Fingerprint, Tier
from tests.fixture_images import (
    crop_10, make_image, reencode_q60, resize_half, to_png_bytes, watermark,
)

ORIGINAL = compute_hashes(to_png_bytes(make_image(1)))

# Bit masks with known popcounts, XOR'd against a zeroed baseline to build
# CandidateHashes at an exact, hand-computed hamming distance -- no images needed.
_MASK_2 = 0b11  # popcount 2
_MASK_5 = 0b11111  # popcount 5
_MASK_11 = (1 << 11) - 1  # popcount 11
_MASK_20 = (1 << 20) - 1  # popcount 20 (beyond POSSIBLE_MIN_MAX -> no tier)

_CREATED_AT = datetime(2026, 1, 1, tzinfo=timezone.utc)


def _fp(id_: int, label: str, hashes: CandidateHashes) -> Fingerprint:
    return Fingerprint(id=id_, label=label, hashes=hashes, created_at=_CREATED_AT, source_path=None)


def _tier_of(data: bytes) -> Tier | None:
    return match_tier(ORIGINAL, compute_hashes(data))[0]


def test_hamming():
    assert hamming(0b1010, 0b1010) == 0
    assert hamming(0b1010, 0b0101) == 4


def test_byte_identical_is_exact():
    assert _tier_of(to_png_bytes(make_image(1))) == Tier.EXACT


def test_resize_detected():
    assert _tier_of(to_png_bytes(resize_half(make_image(1)))) in (Tier.EXACT, Tier.PROBABLE)


def test_reencode_q60_detected():
    assert _tier_of(reencode_q60(make_image(1))) in (Tier.EXACT, Tier.PROBABLE)


def test_watermark_detected():
    assert _tier_of(to_png_bytes(watermark(make_image(1)))) in (Tier.EXACT, Tier.PROBABLE)


def test_crop_10_detected_at_least_possible():
    assert _tier_of(to_png_bytes(crop_10(make_image(1)))) is not None


def test_no_false_positives_against_unrelated_corpus():
    for seed in range(100, 160):
        tier = _tier_of(to_png_bytes(make_image(seed)))
        assert tier not in (Tier.EXACT, Tier.PROBABLE), f"seed {seed} false positive: {tier}"


def test_best_match_picks_the_matching_fingerprint():
    cand = CandidateHashes(sha256="cand-sha", phash=0, dhash=0, ahash=0, whash=0)
    exact = _fp(1, "exact", CandidateHashes(sha256="cand-sha", phash=0, dhash=0, ahash=0, whash=0))
    no_match = _fp(
        2,
        "unrelated",
        CandidateHashes(
            sha256="unrelated-sha", phash=_MASK_20, dhash=_MASK_20, ahash=_MASK_20, whash=_MASK_20
        ),
    )

    # List order (no_match first) proves selection isn't just "first in list".
    result = best_match([no_match, exact], cand)

    assert result is not None
    fp, tier, score = result
    assert fp is exact
    assert tier == Tier.EXACT
    assert score == 0


def test_best_match_tier_rank_beats_lower_score():
    cand = CandidateHashes(sha256="cand-sha-2", phash=0, dhash=0, ahash=0, whash=0)
    # EXACT via phash <= EXACT_PHASH_MAX, but with a nonzero (worse) score of 2.
    exact_worse_score = _fp(
        10, "exact-score-2", CandidateHashes(sha256="fp-a-sha", phash=_MASK_2, dhash=0, ahash=0, whash=0)
    )
    # PROBABLE with a strictly better (lower) score of 0: dmin=0 via dhash, phash
    # distance (11) is >2 (no EXACT) and >PROBABLE_FAMILY_MAX (excluded from the
    # close-families count), ahash/whash distance 5 each keep close_families >= 2.
    probable_better_score = _fp(
        11,
        "probable-score-0",
        CandidateHashes(sha256="fp-b-sha", phash=_MASK_11, dhash=0, ahash=_MASK_5, whash=_MASK_5),
    )

    result = best_match([probable_better_score, exact_worse_score], cand)

    assert result is not None
    fp, tier, score = result
    # Tier rank (EXACT beats PROBABLE) wins the tie-break even though the
    # PROBABLE candidate has the numerically lower score.
    assert fp is exact_worse_score
    assert tier == Tier.EXACT
    assert score == 2


def test_best_match_none_on_empty_fingerprint_list():
    cand = CandidateHashes(sha256="cand-sha-3", phash=0, dhash=0, ahash=0, whash=0)
    assert best_match([], cand) is None


def test_best_match_none_when_no_fingerprint_reaches_any_tier():
    cand = CandidateHashes(sha256="cand-sha-4", phash=0, dhash=0, ahash=0, whash=0)
    unrelated = _fp(
        99,
        "unrelated",
        CandidateHashes(
            sha256="totally-different", phash=_MASK_20, dhash=_MASK_20, ahash=_MASK_20, whash=_MASK_20
        ),
    )
    assert best_match([unrelated], cand) is None
