import httpx
import pytest

from ncid.core.sources.base import (
    DownloadRejected, SourceSpec, download_image, parse_source_spec,
)


def test_parse_specs():
    assert parse_source_spec("url:https://a.example/p") == SourceSpec("url", "https://a.example/p")
    assert parse_source_spec("domain:example.com") == SourceSpec("domain", "example.com")
    assert parse_source_spec("reddit:r/pics") == SourceSpec("reddit", "r/pics")


@pytest.mark.parametrize("bad", ["", "ftp:x", "reddit:pics", "url:notaurl", "example.com"])
def test_parse_rejects(bad):
    with pytest.raises(ValueError):
        parse_source_spec(bad)


async def _client(handler):
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


async def test_download_ok():
    async with await _client(lambda req: httpx.Response(
            200, content=b"imgbytes", headers={"content-type": "image/png"})) as c:
        assert await download_image(c, "https://x/i.png", 100) == b"imgbytes"


async def test_download_rejects_non_image():
    async with await _client(lambda req: httpx.Response(
            200, content=b"<html>", headers={"content-type": "text/html"})) as c:
        with pytest.raises(DownloadRejected) as e:
            await download_image(c, "https://x/i.png", 100)
        assert e.value.reason == "not-image"


async def test_download_rejects_oversize():
    async with await _client(lambda req: httpx.Response(
            200, content=b"x" * 200, headers={"content-type": "image/png"})) as c:
        with pytest.raises(DownloadRejected) as e:
            await download_image(c, "https://x/i.png", 100)
        assert e.value.reason == "too-large"


async def test_download_rejects_non_200_status():
    async with await _client(lambda req: httpx.Response(404)) as c:
        with pytest.raises(DownloadRejected) as e:
            await download_image(c, "https://x/i.png", 100)
        assert e.value.reason == "http-error"


async def test_download_rejects_transport_error():
    def handler(req):
        raise httpx.ConnectError("boom", request=req)

    async with await _client(handler) as c:
        with pytest.raises(DownloadRejected) as e:
            await download_image(c, "https://x/i.png", 100)
        assert e.value.reason == "http-error"
